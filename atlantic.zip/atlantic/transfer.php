<?php session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login-appexi.php");
    exit();
}

if (!isset($_POST['submit'])) {
    header("Location: dashboard.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$amount = $_POST['amount'];

require __DIR__ . "/dbcon.php";

// Get user balance and disabled status
$stmt = $mysqli->prepare("SELECT bal1, disabled FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($balance, $disabled);
$stmt->fetch();
$stmt->close();

// Check if user is disabled
if ($disabled == 1) {
    $_SESSION['error'] = "Your account has been disabled.";
    header("Location: dashboard.php");
    exit();
}

if ($balance < $amount) {
    $_SESSION['error'] = "Insufficient balance. Your balance is $balance.";
    header("Location: dashboard.php");
    exit();
}

$receiver_name = $_POST['receiver_name'];
$account_number = $_POST['account_number'];
$bank_name = $_POST['bank_name'];
$swift_code = $_POST['swift_code'];
$country = $_POST['country'];
$date = date('Y-m-d H:i:s');
$transaction_id = uniqid();

// Generate OTP code and save to the database
$otp_code = rand(100000, 999999);
$stmt = $mysqli->prepare("INSERT INTO otp(user_id, otp_code) VALUES (?, ?)");
$stmt->bind_param("is", $user_id, $otp_code);
$stmt->execute();
$stmt->close();

// Insert transaction details into the database
$stmt = $mysqli->prepare("INSERT INTO transactions (user_id, receiver_name, account_number, bank_name, swift_code, amount, date, country, transaction_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("issssisss", $user_id, $receiver_name, $account_number, $bank_name, $swift_code, $amount, $date,$country, $transaction_id);
$stmt->execute();
$stmt->close();

// Update user's balance in the database
$new_balance = $balance - $amount;
$stmt = $mysqli->prepare("UPDATE users SET bal1 = ? WHERE id = ?");
$stmt->bind_param("di", $new_balance, $user_id);
$stmt->execute();
$stmt->close();

// Redirect to OTP form page
header("Location: otp_form.php");
exit();
?>