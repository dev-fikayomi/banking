var btnSpace = document.querySelector(".btn-space");
var switchh = document.querySelector(".switch");


function togg() {
    btnSpace.classList.toggle("active");
    switchh.classList.toggle("active");
}
