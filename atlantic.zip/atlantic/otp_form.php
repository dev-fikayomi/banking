
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP form</title>
    <link rel="shortcut icon" href="\appexi project\appex-i-bank-logo.png" type="image/x-icon">
    <link rel="stylesheet" href="appex-checking.css">
</head>
<body>
    <div class="background"></div>
    <main>
      
      
      
    
        <form method="post" action="otp_verify.php" >
            <div>
                <label for="">
                    Enter OTP Code
                </label>
                <input type="text" name="otp_code" required>
            </div>
           
           
            <button type="submit" name="submit">
               Verify
            </button>
        </form>
    </main>
   
    <script src="checking.js"></script>
    <script src="//code.tidio.co/qxir3eqphzl98gyvbojezqtur0y9wo8g.js" async></script>
</body>
</html>