var button = document.querySelector(".btn-space");
var button2 = document.querySelector(".btn-space2");
var button3 = document.querySelector(".btn-space3");
var switchh = document.querySelector(".switch");
var switchh2 = document.querySelector(".switch2");
var switchh3 = document.querySelector(".switch3");

button.addEventListener("click", () =>{
    switchh.classList.toggle("active");
    button.classList.toggle("active");
});
button2.addEventListener("click", () =>{
    switchh2.classList.toggle("active");
    button2.classList.toggle("active");
});
button3.addEventListener("click", () =>{
    switchh3.classList.toggle("active");
    button3.classList.toggle("active");
});