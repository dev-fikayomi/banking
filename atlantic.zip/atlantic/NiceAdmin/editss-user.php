<?php
// Check if user is logged in and has admin role
// session_start();
// if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin') {
//     header('Location: login.php');
//     exit;
// }

// Connect to database
$host = "localhost";
$user = "root";
$password = "";
$dbname = "login_db";
$conn = mysqli_connect($host, $user, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if ID parameter is set
if (isset($_GET["id"])) {
    $id = mysqli_real_escape_string($conn, $_GET["id"]);

    // Query the database for the user with the specified ID
    $sql = "SELECT * FROM users WHERE id = '$id'";
    $result = mysqli_query($conn, $sql);

    // Check if a row is returned
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $acc1 = $row["bal1"];
        $acc2 = $row["bal2"];
        $acc3 = $row["bal3"];
    } else {
        // No rows returned, show an error message
        echo "User not found.";
        exit;
    }
} else {
    // ID parameter not set, show an error message
    echo "User ID not specified.";
    exit;
}

// Check if form is submitted
if (isset($_POST["submit"])) {
    $acc1 = mysqli_real_escape_string($conn, $_POST["bal1"]);
    $acc2 = mysqli_real_escape_string($conn, $_POST["bal2"]);
    $acc3 = mysqli_real_escape_string($conn, $_POST["bal3"]);

    // Update the user's data in the database
    $sql = "UPDATE users SET bal1 = '$acc1', bal2 = '$acc2', bal3 ='$acc3'  WHERE id = '$id'";
    if (mysqli_query($conn, $sql)) {
        // User data updated successfully, redirect to admin page
        header("Location:tables-general.php");
        exit;
    } else {
        // Error updating user data, show an error message
        echo "Error: " . mysqli_error($conn);
    }
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h1>Edit Account Balance</h1>
    <form method="post">
        <div class="form-group">
            <label for="username">Username:</label>
            <input type="text" class="form-control" name="username" value="<?php echo $acc1; ?>">
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="text" class="form-control" name="email" value="<?php echo $acc2; ?>">
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="text" class="form-control" name="email" value="<?php echo $acc3; ?>">
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Save</button>
    </form>
</div>
</body>
</html>
