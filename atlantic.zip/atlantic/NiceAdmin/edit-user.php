<?php
// ... previous code for connecting to database and retrieving user data

if(isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    $sql = "UPDATE users SET  nname='$name', email='$email' WHERE id='$id'";
    if (mysqli_query($conn, $sql)) {
        // Redirect to admin page after successful update
        header("Location: tabbles-general.php");
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}
?>

<!-- HTML form for editing user details -->
<form method="POST">
    <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
    <div class="form-group">
        <label for="name">Name:</label>
        <input type="text" class="form-control" name="nname" value="<?php echo $name['nname']; ?>">
    </div>
    <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" class="form-control" name="email" value="<?php echo $email['email']; ?>">
    </div>
    <button type="submit" name="update" class="btn btn-primary">Update</button>
</form>
