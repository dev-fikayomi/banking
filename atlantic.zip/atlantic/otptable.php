<?php
require __DIR__ . "/dbcon.php";


$stmt = $mysqli->query("SELECT * FROM otp");
$otp_records = $stmt->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>OTP Records</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

</head>
<body>
    <div class="container">
        <h1>OTP Records</h1>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User ID</th>
                    <th>OTP Code</th>
                    <th>Created At</th>
                    <th>Used</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($otp_records as $record) { ?>
                    <tr>
                        <td><?php echo $record['id']; ?></td>
                        <td><?php echo $record['user_id']; ?></td>
                        <td><?php echo $record['otp_code']; ?></td>
                        <td><?php echo $record['created_at']; ?></td>
                        <td><?php echo $record['used']; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
