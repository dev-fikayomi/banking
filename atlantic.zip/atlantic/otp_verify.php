<?php session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

require __DIR__ . "/dbcon.php";

$user_id = $_SESSION['user_id'];
$otp_code = $_POST['otp_code'];

// Verify OTP code
$stmt = $mysqli->prepare("SELECT id FROM otp WHERE user_id = ? AND otp_code = ? AND used = 0");
$stmt->bind_param("is", $user_id, $otp_code);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows != 1) {
    $_SESSION['error'] = "Invalid or used OTP code.";
    echo '<script>alert("INVALID OTP CODE INPUTED ❌");window.location.href = "otp_form.php";</script>';
    // header("Location: otp_form.php");
    exit();
}

// Delete used OTP code from the database
$stmt = $mysqli->prepare("DELETE FROM otp WHERE user_id = ? AND otp_code = ?");
$stmt->bind_param("is", $user_id, $otp_code);
$stmt->execute();
$stmt->close();

// Deduct amount from user balance
$stmt = $mysqli->prepare("SELECT bal1 FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($balance);
$stmt->fetch();
$stmt->close();

$amount = $_POST['amount'];
$new_balance = $balance - $amount;

$stmt = $mysqli->prepare("UPDATE users SET bal1 = ? WHERE id = ?");
$stmt->bind_param("di", $new_balance, $user_id);
$stmt->execute();
$stmt->close();

$_SESSION['success'] = "Transaction successful.";

echo '<script>alert("Transaction successful ✅."); window.location.href = "dashboard.php";</script>';
exit();
?>